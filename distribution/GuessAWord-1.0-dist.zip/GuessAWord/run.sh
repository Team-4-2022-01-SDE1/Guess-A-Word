#!/usr/bin/env sh

#     java -classpath GuessAWord-1.0.jar: com.guessaword.client.Main

#     Note that your application JAR stays on the classpath, regardless of whether you're using additional libraries or not.

#     Run shell to start application.


java -classpath GuessAWord-1.0.jar: com.guessaword.Main
